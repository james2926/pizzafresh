<template>
    <div><router-link to="/login"> go to login</router-link>
 
    </div>
    
</template>

<script>
export default {
  
}
</script>